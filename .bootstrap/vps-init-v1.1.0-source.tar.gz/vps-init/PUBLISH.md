# 发布到 GitHub

为了让一键命令无需 GitHub Token，推荐建立一个 **Public** 仓库，名称建议 `vps-init`。

仓库建立后，需要把项目里的占位符：

```text
bluepanda001/vps-init
```

替换成：

```text
你的GitHub用户名/vps-init
```

然后推送全部源码，并创建 tag：

```text
v1.1.0
```

仓库自带的 GitHub Actions 会运行 `verify/selftest.sh`，生成 `vps-init-1.1.0.tar.gz` 和 `SHA256SUMS`，并创建 Release。

之后一键命令就是：

```bash
bash <(curl -fsSL https://raw.githubusercontent.com/你的GitHub用户名/vps-init/main/install.sh)
```

如果仓库是 Private，匿名 `curl raw.githubusercontent.com/...` 无法直接拉取，不适合作为无需 Token 的一键安装入口。
